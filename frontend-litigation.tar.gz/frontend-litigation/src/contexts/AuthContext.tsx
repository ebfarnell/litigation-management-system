import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { getConfig } from '../utils/config';

interface User {
  userId: string;
  email: string;
  firstName: string;
  lastName: string;
  role: 'master' | 'admin' | 'partner' | 'attorney' | 'paralegal';
  lawFirmId?: string;
  lawFirmName?: string;
  permissions?: string[];
  selectedFirmId?: string; // For master account to switch between firms
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for saved user in localStorage (for demo purposes)
    const savedUser = localStorage.getItem('demoUser');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    setLoading(true);
    let config;
    try {
      try {
        config = getConfig();
      } catch (configError) {
        console.error('Config error:', configError);
        // Use fallback config
        config = {
          apiEndpoint: 'http://localhost:3001',
          region: 'us-west-1',
          userPoolId: 'mock-user-pool-id',
          userPoolClientId: 'mock-client-id',
          identityPoolId: 'mock-identity-pool-id',
          environment: 'demo',
        };
      }
      console.log('Login attempt with config:', config);
      console.log('Attempting login to:', `${config.apiEndpoint}/auth/login`);
      
      const response = await fetch(`${config.apiEndpoint}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      console.log('Response status:', response.status);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Login response error:', errorText);
        throw new Error('Login failed');
      }

      const data = await response.json();
      console.log('Login response data:', data);
      
      if (data.success) {
        setUser(data.data.user);
        localStorage.setItem('demoUser', JSON.stringify(data.data.user));
        localStorage.setItem('demoTokens', JSON.stringify(data.data.tokens));
        console.log('Login successful, user set:', data.data.user);
      } else {
        console.error('Login failed with error:', data.error);
        throw new Error(data.error?.message || 'Login failed');
      }
    } catch (error) {
      console.error('Login error details:', error);
      if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
        console.error('Network error - cannot connect to server at:', config?.apiEndpoint || 'unknown');
        throw new Error('Cannot connect to server. Please check if the server is running.');
      }
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      const config = getConfig();
      await fetch(`${config.apiEndpoint}/auth/logout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setUser(null);
      localStorage.removeItem('demoUser');
      localStorage.removeItem('demoTokens');
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      login,
      logout,
      loading
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};